def render_user_profile(username: str, bio: str) -> str:
    """Starter implementation: unsafe string interpolation."""
    return f'<div class="profile"><h1>{username}</h1><p>{bio}</p></div>'

